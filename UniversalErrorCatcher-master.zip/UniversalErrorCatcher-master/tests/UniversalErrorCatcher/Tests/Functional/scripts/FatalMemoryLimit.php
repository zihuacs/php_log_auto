<?php

ini_set('memory_limit', '1K');

str_repeat('foobar', PHP_INT_MAX);