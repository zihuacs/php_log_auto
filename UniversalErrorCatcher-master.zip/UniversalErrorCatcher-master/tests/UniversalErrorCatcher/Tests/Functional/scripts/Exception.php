<?php

throw new Exception('Foo bar');