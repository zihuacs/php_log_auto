<?php

@trigger_error('a notice', E_USER_WARNING);