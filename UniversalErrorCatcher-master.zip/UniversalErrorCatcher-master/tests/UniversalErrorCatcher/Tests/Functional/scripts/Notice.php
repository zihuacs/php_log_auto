<?php

$a = 100 + $b;