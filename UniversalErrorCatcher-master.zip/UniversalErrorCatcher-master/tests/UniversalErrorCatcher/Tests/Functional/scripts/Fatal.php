<?php

$o = new FooBarClass;