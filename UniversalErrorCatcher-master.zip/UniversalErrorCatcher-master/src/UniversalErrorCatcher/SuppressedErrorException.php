<?php

class SuppressedErrorException extends ErrorException
{
}